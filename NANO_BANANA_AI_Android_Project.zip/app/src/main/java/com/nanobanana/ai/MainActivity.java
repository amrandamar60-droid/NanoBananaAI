package com.nanobanana.ai;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int FILE_REQUEST = 1001;
    private static final String FLOW_URL = "https://labs.google/fx/tools/flow";
    private LinearLayout content;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private boolean english = false;
    private final int BG = Color.rgb(16,16,20), PANEL = Color.rgb(29,29,36);
    private final int YELLOW = Color.rgb(255,212,59), WHITE = Color.WHITE;

    @Override public void onCreate(Bundle state) { super.onCreate(state); showHome(); }

    private TextView txt(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(WHITE); t.setPadding(12,12,12,12); return t;
    }
    private Button btn(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(ColorStateList.valueOf(YELLOW)); b.setOnClickListener(v -> r.run()); return b;
    }
    private void screen(String title) {
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(BG);
        root.setLayoutDirection(english ? View.LAYOUT_DIRECTION_LTR : View.LAYOUT_DIRECTION_RTL);
        TextView h = txt("🍌 NANO BANANA AI",24); h.setTextColor(YELLOW); h.setGravity(Gravity.CENTER); root.addView(h);
        TextView sub = txt(title,16); sub.setGravity(Gravity.CENTER); root.addView(sub);
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(0);
        nav(nav,english?"Home":"الرئيسية",this::showHome);
        nav(nav,english?"Images":"الصور",this::showImages);
        nav(nav,english?"Videos":"الفيديو",this::showVideos);
        nav(nav,english?"Chat":"المحادثة",this::showChat);
        nav(nav,"Google Flow",this::openFlow);
        nav(nav,english?"Gallery":"المعرض",this::showGallery);
        ScrollView ns = new ScrollView(this); ns.setHorizontalScrollBarEnabled(true); ns.addView(nav); root.addView(ns);
        content = new LinearLayout(this); content.setOrientation(1); content.setPadding(16,16,16,16);
        ScrollView sc = new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private void nav(LinearLayout row,String label,Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(WHITE);
        b.setBackgroundTintList(ColorStateList.valueOf(PANEL)); b.setOnClickListener(v->action.run()); row.addView(b);
    }
    private void msg(String s) { TextView t=txt(s,16); t.setBackgroundColor(PANEL); content.addView(t); }
    private void prompt(String hint) {
        EditText e=new EditText(this); e.setTextColor(WHITE); e.setHintTextColor(Color.LTGRAY);
        e.setHint(hint); e.setMinLines(2); e.setGravity(Gravity.TOP|Gravity.START); content.addView(e);
    }
    private void showHome() {
        screen(english?"AI Studio":"استوديو الذكاء الاصطناعي");
        msg(english?"Welcome to NANO BANANA AI":"أهلاً بك في NANO BANANA AI 🍌");
        content.addView(btn(english?"Create Image":"إنشاء صورة",this::showImages));
        content.addView(btn(english?"Create Video":"إنشاء فيديو",this::showVideos));
        content.addView(btn(english?"Open Google Flow":"فتح Google Flow",this::openFlow));
        content.addView(btn(english?"My Gallery":"معرض أعمالي",this::showGallery));
        content.addView(btn(english?"Change Language":"تغيير اللغة",()->{english=!english;showHome();}));
        msg(english?"AI generation requires a connected provider/API.":"توليد الصور والفيديو والمحادثة يحتاج إلى ربط خدمة API حقيقية.");
    }
    private void showImages() {
        screen(english?"AI Images":"إنشاء الصور"); msg(english?"Describe your image":"اكتب وصف الصورة");
        prompt(english?"Describe your image...":"اكتب وصف الصورة...");
        content.addView(btn(english?"Choose image":"استيراد صورة من الهاتف",()->pick("image/*")));
        content.addView(btn(english?"Open image generator":"فتح أداة الصور",()->openSite("https://www.freepik.com/ai")));
        msg(english?"Connect an image-generation API to generate inside the app.":"يلزم ربط API لتوليد الصور داخل التطبيق.");
    }
    private void showVideos() {
        screen(english?"AI Videos":"إنشاء الفيديوهات"); msg(english?"Describe your video":"اكتب وصف الفيديو");
        prompt(english?"Describe your video...":"اكتب وصف الفيديو...");
        content.addView(btn(english?"Import media":"استيراد صورة أو فيديو",()->pick("*/*")));
        content.addView(btn(english?"Open Google Flow":"إنشاء فيديو باستخدام Google Flow",this::openFlow));
        msg(english?"Google controls account access and WebView support.":"تسجيل الدخول ودعم WebView يخضعان لسياسات Google وحسابك.");
    }
    private void showChat() {
        screen(english?"AI Chat":"المحادثة الذكية"); msg(english?"AI Assistant":"المساعد الذكي");
        prompt(english?"Write your message...":"اكتب رسالتك هنا...");
        content.addView(btn(english?"Send":"إرسال",()->Toast.makeText(this,
            english?"Connect an AI chat API first.":"يلزم ربط API للمحادثة أولاً.",Toast.LENGTH_LONG).show()));
    }
    private void showGallery() {
        screen(english?"My Gallery":"المعرض");
        content.addView(btn(english?"Import Images":"اختيار صور",()->pick("image/*")));
        content.addView(btn(english?"Import Videos":"اختيار فيديوهات",()->pick("video/*")));
        msg(english?"The Android file picker opens; files are not stored in an in-app gallery yet.":"يتم فتح مستعرض ملفات الهاتف؛ لم يتم إنشاء معرض داخلي دائم بعد.");
    }
    private void pick(String type) {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        try { startActivityForResult(i,FILE_REQUEST); }
        catch(Exception e){Toast.makeText(this,"تعذر فتح الملفات",Toast.LENGTH_SHORT).show();}
    }
    private void openFlow(){openSite(FLOW_URL);}
    private void openSite(String url) {
        screen(english?"Web tool":"أداة عبر الإنترنت"); webView=new WebView(this);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager cm=CookieManager.getInstance(); cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(webView,true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                try{startActivityForResult(i,FILE_REQUEST);}catch(Exception e){fileCallback=null;callback.onReceiveValue(null);}
                return true;
            }
        });
        webView.setDownloadListener((url2,ua,disp,mime,len)->download(url2,ua,disp,mime));
        content.addView(webView,new LinearLayout.LayoutParams(-1,0,1)); webView.loadUrl(url);
    }
    private void download(String url,String ua,String disposition,String mime) {
        try {
            DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));
            r.setTitle(URLUtil.guessFileName(url,disposition,mime));
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            String cookie=CookieManager.getInstance().getCookie(url); if(cookie!=null)r.addRequestHeader("Cookie",cookie);
            if(ua!=null)r.addRequestHeader("User-Agent",ua);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,URLUtil.guessFileName(url,disposition,mime));
            DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE); if(dm!=null)dm.enqueue(r);
            Toast.makeText(this,english?"Download started":"بدأ التنزيل",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,english?"Download failed":"فشل التنزيل",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data); if(request!=FILE_REQUEST)return;
        Uri[] uris=null;
        if(result==RESULT_OK&&data!=null){
            if(data.getClipData()!=null){int n=data.getClipData().getItemCount();uris=new Uri[n];for(int x=0;x<n;x++)uris[x]=data.getClipData().getItemAt(x).getUri();}
            else if(data.getData()!=null)uris=new Uri[]{data.getData()};
        }
        if(fileCallback!=null){fileCallback.onReceiveValue(uris);fileCallback=null;}
        else if(uris!=null)Toast.makeText(this,"تم اختيار "+uris.length+" ملف",Toast.LENGTH_SHORT).show();
    }
    @Override public void onBackPressed(){
        if(webView!=null&&webView.canGoBack())webView.goBack();else showHome();
    }
    @Override protected void onDestroy(){
        if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
        if(webView!=null){webView.stopLoading();webView.destroy();webView=null;} super.onDestroy();
    }
}
