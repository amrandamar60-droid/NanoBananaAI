NANO BANANA AI Android source project. See README_AR.txt for instructions.
